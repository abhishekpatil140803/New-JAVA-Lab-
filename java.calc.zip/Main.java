public class Calc{
    private int a;
    private int b;
    Calc(int i, int j)
    {
        a=i;
        b=j;
    }
    public void add()
    {
        int A =a+b;
        System.out.println("Add is " +A);
    }
    public void sub()
    {
        int S =a-b;
        System.out.println("sub is " +S);
    }
    public void mul()
    {
        int M =a*b;
        System.out.println("mul is " +M);
        
    }
    public void div(){
        int D =a/b;
        System.out.println("div is " +D);
    }
    public static void main(String[]args)
    {
        Calc c1=new Calc(11,12);
        c1.add();
        c1.mul();
        c1.sub();
        c1.div();
    }
    
}
