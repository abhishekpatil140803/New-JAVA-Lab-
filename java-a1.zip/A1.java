import java.util.Scanner;
public class A1{
    public static void main(String[]args){
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        System.out.println("The number is : " +n);
    }
}