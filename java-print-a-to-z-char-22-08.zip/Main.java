import java.util.Scanner;
class Main{
    public static void main (String args[]) {
	for (char i='A';i<='Z';i++)
		System.out.println(i);
		
	}
}
