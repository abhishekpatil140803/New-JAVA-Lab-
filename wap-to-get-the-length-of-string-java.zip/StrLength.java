 class StrLength
{
	public static void main(String[] args) {
	    String greet="Helle! World";
		System.out.println("String : "+greet);
		int length =greet.length();
		System.out.println("Length : "+length);
	}
}
