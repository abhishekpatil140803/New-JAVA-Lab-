
 class StrLength
{
	public static void main(String[] args) {
	    String s1="Helle";
	    String s2="Bye";
	    String s3=s1.substring(2,4);
		System.out.println(s3);
	}
}
