import java.util.*;    
public class EnrollmentID
 {
 	public static void main(String[] args) 
 	{
 	    Scanner sc=new Scanner(System.in);
 	    Scanner sc1=new Scanner(System.in);
 	    System.out.println("Enter the name : ");
 	    String name=sc.nextLine();
 	    
 	    System.out.println("Enter the year : ");
 	    int i=sc.nextInt();
 	    
 	    String year=String.valueOf(i);
 	    System.out.println("Enter the enrollment number : ");
 	    
 	    String enrollment=sc1.nextLine();
 	     String e=enrollment.substring(1,4);
 	    
 	    String EnrollId1=(name.concat(year)).concat("Enroll");
 	     System.out.println(EnrollId1+"@acropolis.in");
 	}
 	}