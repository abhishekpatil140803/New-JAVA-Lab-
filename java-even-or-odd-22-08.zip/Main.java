import java.util.Scanner;
public class Main{
    public static void main (String args[]) {
		Scanner sc =new Scanner (System.in);
		System.out.println("enter int");
		int n=sc.nextInt();
		if(n%2==0)
		System.out.print("num is even : ");
		else
		System.out.print("num is odd : ");
		
	}
}
