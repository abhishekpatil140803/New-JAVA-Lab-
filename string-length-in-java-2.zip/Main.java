
//String in Java
class Main
{
    public static void main (String[]args){
    String first ="Java";
    System.out.println("first String : "+first);
    String second ="Programming";
    System.out.println("second String : "+second);
    String joinedString =first.concat(second);
    System.out.println("joined String : "+joinedString);
    
    }
}
